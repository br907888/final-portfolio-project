import React, { useState } from 'react';
import { StatusBar } from 'react-native';
import Constants from 'expo-constants';
import Animated, {
  useSharedValue,
  useAnimatedRef,
  withTiming,
  Easing,
  scrollTo,
  useAnimatedReaction,
} from 'react-native-reanimated';
import styled from 'styled-components/native';

import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomeSection from './sections/HomeSection';
import AboutSection from './sections/AboutSection';
import ProjectsSection from './sections/ProjectsSection';
import ContactSection from './sections/ContactSection';

export default function App() {
  const scrollRef = useAnimatedRef();
  const targetY = useSharedValue(0);

 
  const [sectionOffsets, setSectionOffsets] = useState({
    home: 0,
    about: 0,
    projects: 0,
    contact: 0,
  });

  
  const handleSectionLayout = (section, event) => {
    const { y } = event.nativeEvent.layout;
    setSectionOffsets(prev => ({
      ...prev,
      [section]: y,
    }));
  };

  
  const smoothScrollTo = yPosition => {
    targetY.value = withTiming(yPosition, {
      duration: 1500,
      easing: Easing.out(Easing.quad),
    });
  };

  
  useAnimatedReaction(
    () => targetY.value,
    newValue => {
      scrollTo(scrollRef, 0, newValue, false);
    }
  );

  return (
    <Container>
      <StatusBar style="auto" />

      
      <Navbar
        onHomePress={() => smoothScrollTo(sectionOffsets.home)}
        onAboutPress={() => smoothScrollTo(sectionOffsets.about)}
        onProjectsPress={() => smoothScrollTo(sectionOffsets.projects)}
        onContactPress={() => smoothScrollTo(sectionOffsets.contact)}
      />

      
      <AnimatedScrollView
        ref={scrollRef}
        contentContainerStyle={{ paddingBottom: 20 }}
        showsVerticalScrollIndicator
        scrollEventThrottle={16}
      >
        <HomeSection onLayout={e => handleSectionLayout('home', e)} />
        <AboutSection onLayout={e => handleSectionLayout('about', e)} />

       
        <ProjectsSection onLayout={e => handleSectionLayout('projects', e)} />

        <ContactSection onLayout={e => handleSectionLayout('contact', e)} />
      </AnimatedScrollView>

      <Footer />
    </Container>
  );
}

const Container = styled.SafeAreaView`
  flex: 1;
  background-color: #f5f5f5;
  padding-top: ${Constants.statusBarHeight}px;
`;

const AnimatedScrollView = styled(Animated.ScrollView)`
  flex: 1;
`;

