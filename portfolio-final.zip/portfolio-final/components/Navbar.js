import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const windowWidth = Dimensions.get('window').width;

export default function Navbar({ onHomePress, onAboutPress, onProjectsPress, onContactPress }) {
  const [menuOpen, setMenuOpen] = useState(false);
  
  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };
  
  return (
    <View style={styles.navbar}>
      <Text style={styles.logo}>brock adams</Text>
      
      {windowWidth > 768 ? (
        // Desktop navigation
        <View style={styles.navItems}>
          <TouchableOpacity onPress={onHomePress}>
            <Text style={styles.navItem}>Home</Text>
          </TouchableOpacity>
          
          <TouchableOpacity onPress={onAboutPress}>
            <Text style={styles.navItem}>About</Text>
          </TouchableOpacity>
          
          <TouchableOpacity onPress={onProjectsPress}>
            <Text style={styles.navItem}>Projects</Text>
          </TouchableOpacity>
          
          <TouchableOpacity onPress={onContactPress}>
            <Text style={styles.navItem}>Contact</Text>
          </TouchableOpacity>
        </View>
      ) : (
        // Mobile hamburger menu
        <View>
          <TouchableOpacity onPress={toggleMenu}>
            <Ionicons name={menuOpen ? "close" : "menu"} size={28} color="#fff" />
          </TouchableOpacity>
          
          {menuOpen && (
            <View style={styles.mobileMenu}>
              <TouchableOpacity 
                style={styles.mobileMenuItem}
                onPress={() => {
                  onHomePress();
                  setMenuOpen(false);
                }}
              >
                <Text style={styles.mobileMenuText}>Home</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.mobileMenuItem}
                onPress={() => {
                  onAboutPress();
                  setMenuOpen(false);
                }}
              >
                <Text style={styles.mobileMenuText}>About</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.mobileMenuItem}
                onPress={() => {
                  onProjectsPress();
                  setMenuOpen(false);
                }}
              >
                <Text style={styles.mobileMenuText}>Projects</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.mobileMenuItem}
                onPress={() => {
                  onContactPress();
                  setMenuOpen(false);
                }}
              >
                <Text style={styles.mobileMenuText}>Contact</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  navbar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#333',
    zIndex: 100,
  },
  logo: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'Arial',
  },
  navItems: {
    flexDirection: 'row',
  },
  navItem: {
    color: '#fff',
    marginLeft: 20,
    fontSize: 16,
  },
  mobileMenu: {
    position: 'absolute',
    top: 50,
    right: 0,
    backgroundColor: '#333',
    width: 200,
    padding: 10,
    borderRadius: 5,
  },
  mobileMenuItem: {
    padding: 15,
  },
  mobileMenuText: {
    color: '#fff',
    fontSize: 16,
  }
});
