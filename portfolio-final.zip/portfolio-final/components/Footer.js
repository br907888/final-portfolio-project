import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <View style={styles.footer}>
 
      

    </View>
  );
}

const styles = StyleSheet.create({
  footer: {
    backgroundColor: '#333',
    padding: 20,
    alignItems: 'center',
  },
  socialIcons: {
    flexDirection: 'row',
    marginBottom: 15,
  },
  iconButton: {
    marginHorizontal: 10,
  },
  copyright: {
    color: '#ccc',
    fontSize: 14,
  }
});