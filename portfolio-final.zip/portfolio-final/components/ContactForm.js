import React from 'react';
import styled from 'styled-components/native';
import { Linking } from 'react-native';

export default function ContactInfo() {
  return (
    <Container>
      <Title>Contact Me</Title>

      <InfoGroup>
        <Label>Name</Label>
        <Value>Brock Adams</Value>
      </InfoGroup>

      <InfoGroup>
        <Label>Email</Label>
        <LinkText onPress={() => Linking.openURL('mailto:brock@example.com')}>
          brock@example.com
        </LinkText>
      </InfoGroup>

      <InfoGroup>
        <Label>Phone</Label>
        <Value>(555) 123-4567</Value>
      </InfoGroup>

      <InfoGroup>
        <Label>GitHub</Label>
        <LinkText onPress={() => Linking.openURL('https://github.com/yourusername')}>
          github.com/yourusername
        </LinkText>
      </InfoGroup>
    </Container>
  );
}
const Container = styled.View`
  padding: 20px;
  background-color: #f5f5f5;
  border-radius: 8px;
  width: 100%;
  max-width: 500px;
  align-self: center;
`;

const Title = styled.Text`
  font-size: 22px;
  font-weight: bold;
  margin-bottom: 20px;
  text-align: center;
`;

const InfoGroup = styled.View`
  margin-bottom: 15px;
`;

const Label = styled.Text`
  font-size: 14px;
  color: #666;
  margin-bottom: 4px;
`;

const Value = styled.Text`
  font-size: 16px;
  color: #000;
`;

const LinkText = styled.Text`
  font-size: 16px;
  color: #3b9ca1;
`;
