import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, Dimensions, Animated, Pressable } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import Feather from '@expo/vector-icons/Feather';

const windowWidth = Dimensions.get('window').width;

export default function AboutSection({ onLayout }) {
  const [scale] = useState(new Animated.Value(1));
  const [color, setColor] = useState('#000'); 

  const handleHoverIn = () => {
    Animated.spring(scale, {
      toValue: 1.1,
      useNativeDriver: true,
    }).start();
    setColor('#3b9ca1'); 
  };

  const handleHoverOut = () => {
    Animated.spring(scale, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
    setColor('#000'); 
  };

  const skills = [
    { name: 'Figma', icon: 'figma', type: 'feather' },
    { name: 'JavaScript', icon: 'language-javascript', type: 'material' },
    { name: 'React/React Native', icon: 'react', type: 'material' },
    { name: 'HTML/CSS', icon: 'language-html5', type: 'material' },
    { name: 'Adobe Photoshop', icon: 'camera', type: 'material' },
    { name: 'Graphic Design', icon: 'pencil', type: 'material' },
    { name: 'UI/UX Design', icon: 'palette', type: 'material' },
  ];

  return (
    <View onLayout={onLayout} style={styles.container}>
      <Pressable onHoverIn={handleHoverIn} onHoverOut={handleHoverOut}>
        <Animated.Text style={[styles.sectionTitle, { transform: [{ scale }], color }]}>
          hello there!
        </Animated.Text>
      </Pressable>

      <View style={styles.separator} />

      <View style={styles.content}>
        <Image
          source={require('../assets/brock.jpg')}
          style={styles.profileImage}
        />

        <View style={styles.bio}>
          <Text style={styles.bioText}>
            I am an impassioned and driven designer based out of Orlando, Florida. Using my expertise
            in both graphic and web design, I have been developing unique web and mobile experiences
            for over three years.
          </Text>
          <Text style={styles.bioText}>
            I am proficient in JavaScript, React, React Native, Adobe Photoshop, Adobe Premiere Pro,
            and Adobe Illustrator. My skillset ensures that the digital experiences I develop are
            intuitive, engaging, and visually appealing to all.
          </Text>
          <Text style={styles.bioText}>
            When I'm not developing, I enjoy drawing, watching classic movies, running, and learning
            too much about Star Wars lore!
          </Text>
        </View>
      </View>

      <Text style={styles.skillsTitle}>my skills</Text>
      <View style={styles.skillsContainer}>
        {skills.map((skill, index) => (
          <View key={index} style={styles.skillItem}>
            {skill.type === 'material' ? (
              <MaterialCommunityIcons name={skill.icon} size={32} color="#3b9ca1" />
            ) : (
              <Feather name={skill.icon} size={32} color="#3b9ca1" />
            )}
            <Text style={styles.skillName}>{skill.name}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#daf2f2',
  },
  sectionTitle: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
    fontFamily: 'Arial',
  },
  separator: {
    height: 4,
    width: 60,
    backgroundColor: '#3b9ca1',
    marginBottom: 30,
    alignSelf: 'center',
  },
  content: {
    flexDirection: windowWidth > 768 ? 'row' : 'column',
    alignItems: 'center',
    marginBottom: 30,
    maxWidth: 700,
    alignSelf: 'center',
  },
  profileImage: {
    width: 180,
    height: 180,
    borderRadius: 90,
    marginRight: windowWidth > 768 ? 30 : 0,
    marginBottom: windowWidth > 768 ? 0 : 20,
  },
  bio: {
    flex: 1,
  },
  bioText: {
    fontSize: 18,
    lineHeight: 24,
    color: '#444',
    marginBottom: 15,
  },
  skillsTitle: {
    fontSize: 30
    ,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    fontFamily: 'Arial',
  },
  skillsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  skillItem: {
    alignItems: 'center',
    margin: 15,
    width: 100,
  },
  skillName: {
    marginTop: 8,
    fontSize: 16,
    textAlign: 'center',
  },
});
