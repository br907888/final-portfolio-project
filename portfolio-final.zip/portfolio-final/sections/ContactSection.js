import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Pressable,
  Linking,
} from 'react-native';

export default function ContactSection({ onLayout }) {
  /* ---- Animated title state (ONLY ADDITION) ---- */
  const [scale] = useState(new Animated.Value(1));
  const [color, setColor] = useState('#000');

  const handleHoverIn = () => {
    Animated.spring(scale, {
      toValue: 1.1,
      useNativeDriver: true,
    }).start();
    setColor('#3b9ca1');
  };

  const handleHoverOut = () => {
    Animated.spring(scale, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
    setColor('#000');
  };

  // Animated values for each row (Email, Phone)
  const animations = useRef([
    new Animated.Value(0),
    new Animated.Value(0),
  ]).current;

  useEffect(() => {
    Animated.stagger(
      150,
      animations.map(anim =>
        Animated.timing(anim, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        })
      )
    ).start();
  }, []);

  const getAnimatedStyle = anim => ({
    opacity: anim,
    transform: [
      {
        translateY: anim.interpolate({
          inputRange: [0, 1],
          outputRange: [30, 0],
        }),
      },
    ],
  });

  return (
    <View onLayout={onLayout} style={styles.container}>
      <Pressable onHoverIn={handleHoverIn} onHoverOut={handleHoverOut}>
        <Animated.Text
          style={[
            styles.sectionTitle,
            { transform: [{ scale }], color },
          ]}
        >
          contact me!
        </Animated.Text>
      </Pressable>

      <View style={styles.separator} />

      <Text style={styles.sectionDescription}>
        I’d love to connect with you! Please reach out with any inquiries!
      </Text>

      <View style={styles.contactInfo}>
        {/* Email */}
        <Animated.View
          style={[styles.row, getAnimatedStyle(animations[0])]}
        >
          <Text style={styles.label}>Email</Text>
          <Pressable
            onPress={() =>
              Linking.openURL('mailto:brock@example.com')
            }
          >
            <Text style={styles.link}>
              brock.adams@ucf.edu
            </Text>
          </Pressable>
        </Animated.View>

        {/* Phone */}
        <Animated.View
          style={[styles.row, getAnimatedStyle(animations[1])]}
        >
          <Text style={styles.label}>Phone</Text>
          <Text style={styles.value}>
            (407) 668-6801
          </Text>
        </Animated.View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#daf2f2',
  },
  sectionTitle: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  separator: {
    height: 4,
    width: 60,
    backgroundColor: '#3b9ca1',
    marginBottom: 30,
    alignSelf: 'center',
  },
  sectionDescription: {
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 30,
    paddingHorizontal: 20,
    lineHeight: 24,
    color: '#666',
  },
  contactInfo: {
    width: '100%',
  },
  row: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  value: {
    fontSize: 18,
    color: '#333',
  },
  link: {
    fontSize: 18,
    color: '#3b9ca1',
    fontWeight: '500',
  },
});
