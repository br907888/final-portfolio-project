import React, { useRef, useEffect } from 'react';
import { View, Text, StyleSheet, ImageBackground, Animated } from 'react-native';

export default function HomeSection() {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      })
    ]).start();
  }, [fadeAnim, slideAnim]); 

  return (
    <View style={styles.container}>
      <ImageBackground
        source={require('../assets/keys3.jpg')}
        style={styles.backgroundImage}
      >
        <View style={styles.overlay}>
          <Animated.View 
            style={{ 
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }]
            }}
          >
            <Text style={styles.title}>brock adams</Text>
            <Text style={styles.subtitle}>Developer.
            Designer. Artist.</Text>
            <View style={styles.separator} />
            <Text style={styles.tagline}>Producing powerful digital worlds to educate and inpsire. </Text>
          </Animated.View>
        </View>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 700,
    maxWidth: '1100',
  },
  backgroundImage: {
    flex: 1,
    justifyContent: 'center',
    resizeMode: 'cover',
  },
  overlay: {
    backgroundColor: 'rgba(0,0,0,0.6)',
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  title: {
    color: '#fff',
    fontSize: 70
    ,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 15,
    fontFamily: 'arial',
  },
  subtitle: {
    color: '#fff',
    fontSize: 24,
    textAlign: 'center',
    marginBottom: 20,
  },
  separator: {
    height: 4,
    width: 80,
    backgroundColor: '#3b9ca1',
    marginVertical: 20,
    alignSelf: 'center',
  },
  tagline: {
    color: '#ccc',
    fontSize: 18,
    textAlign: 'center',
    fontStyle: 'italic',
  }
});
