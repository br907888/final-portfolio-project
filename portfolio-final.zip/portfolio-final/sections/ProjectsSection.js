import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Image,
  Linking,
  Animated as RNAnimated,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withDelay,
  Easing,
} from 'react-native-reanimated';

import ProjectCard from '../components/ProjectCard';

/* ------------------ DATA ------------------ */

const projects = [
  {
    id: 1,
    title: 'Comet Tales Prototype',
    description: [
      'A high-fidelity educational prototype combining storytelling and exploration to teach students about astronomical topics.',
      
      ' I helmed this project as the Project Manager and lead UI/UX Designer.',
    ],
    link:
      'https://www.figma.com/proto/gsPqmIZWVUKxvTAiO5MpNq/high-fid-prototype',
    caseStudy: {
      overview: {
        heading: 'Project Overview',
        content: [
          'Comet Tales is a dyanmic, interactive learning experience blending exploratory learning with narrative engagement to strengthen the connection between students and astrological concepts. ',
          'A project based on the relationship between digital platforms and improved informal learning, Comet Tales incorporated market and user research, rigorous user testing, and a detailed high-fidelity prototype into a wholisitic approach to educational interface.',
        ],
      },
      images: [
        {
          src: require('../assets/comettales1.jpg'),
          caption: 'Wireframes exploring the visual presentation of Comet Tales.',
        },
      ],
      problem: {
        heading: 'Problem/Market Gaps',
        content: [
          'A market analysis and initial research indicated that there was a significant lack of mobile content for students that incorporated educational elements while still ensuring an entertaining experience. Market competitors were either focused solely on entertainment — with a lack of substantial hierarchy, or based entirely in education, with no strong means to maintain user focus.',
          'Many of these competitors also noticeably lacked any foundational strcuture that encouraged students to retain the information they were enaging with, leading to aimless experiences that left users wanting stronger connections with the educational material. Essentially,these applications either felt too much like play or school, without a healthy balance between the two.',
        ],
      },
      role: {
        heading: 'My Role',
        content: [
          'Project Manager',
          'UX/UI Designer',
          'Information Archiect',
        ],
      },
      solution: {
        heading: 'Design Solution',
        content: [
          'To provide a meaningful solution, I organized a mutli-faceted research phase for my team. We collected user surveys and interviews, conducted think-aloud protocols, explored literature reviews, and synthesized our findings into visualized data.',
          'Our research and user data indicated that students desired the opportunity to explore astrological concepts at their own pace but requested somewhat of a guided structure to facilitate educational navigation. In response to my data visaulization, my team and I developed a dynamic framework that integrated multiple academic approaches into a streamlined experience. Our prototype utilizes exploratory modules complete with mini-game knowledge checks, interactive AR simulations detailing astronomical models like planets, and discussion boards for users to track and share what they learn with others. ',
        ],
      },
      outcome: {
        heading: 'Outcome and Impact',
        content: [
          'User data post-prototype release saw immense user satisfaction, with students feeling a sense of agency and control over their learning. This excited them and ecnouraged the students to learn more about their natural world. Discovery using the application was reported to feel sleek and exploratory in nature — as users with the freedom of modular interaction and the colorful graphical interface of the platform.',
          ' Users felt satisfaction in being able to track their learning and felt a sense of pride in being able to showcase their knowledge. Students were overjoyed and inspired by the fact that they were able to witness their mastery over the topic presented to them. ',
          'Next steps for the prototype involve implementing full mobile functionality leveraging React and potential collaboration with eductational entities like the Kennedy Space Center.',
        ],
      },
      tools: {
        heading: 'Tools Used',
        content: ['Figma', 'UI/UX Research', 'Adobe Aero'],
      },
    },
  },

  {
    id: 2,
    title: 'Dust Buddies Prototype',
    description: [
      'A multi-modal mobile project currently in its prototyping phase, designed to mediate between roommates and encourage chore management through "gamified" education.',
      ' I served as the UI/UX Designer and platform architect for this project.',
    ],
    link:
      'https://www.figma.com/proto/7uX3sVdNdCqSU8qQYmBHSv/Hi-fi-Prototype?node-id=6-367&starting-point-node-id=6%3A367&t=NAQlf870cJmXMN6I-1',
    caseStudy: {
      overview: {
        heading: 'Project Overview',
        content: [
          'Dust Buddies is a dynamic mobile application blending both game-based content and interactive features to assist roommates in chore delegation and conflict mediation while living together. The app – currently in its final prototype, allows users to group with their roommates and schedule tasks.',
          'The platform also encourages a sense of interactivity and collaboration by transforming each task into a game-like challenge, complete with custmoizable avatars and unique artwork. The app also provied various messaging and announcement features so roommates can communicate with each other and promote a sense of accountabilty.',
        ],
      },
      images: [
        {
          src: require('../assets/dustbuddies.jpg'),
          caption: 'Initial character and icon design.',
        },
      ],
      problem: {
        heading: 'problem/market gaps',
        content: [
          'Based on my experience working in higher education and alongside market research, there was a noticeable gap in terms of platforms designed to facilitate living with roommates. Most chore-based trackers on the market are tailored only for families of small children and lack robust features needed for young adults living with each other for the first time. It was also evident that due to rising housing costs, more adults will be adopting a lifestyle involving roommates.',
        ],
      },
      role: {
        heading: 'my role',
        content: ['UI/UX Designer', 'Content Architect', 'Developer'],
      },
      solution: {
        heading: 'design solution',
        content: [
          'Under my lead, my team and I conducted rigorous think-aloud protocols with various users based on a methodology I designed. The tests compared market competitors with our framework and the results indicated that our approach to communication and direct interaction between roommates was the optimal strategy. I visualized our data and used it to construct a platform architecture based on intuitive dialogue and consolidation.',
          'Our key design strategy was to have all of the core features of the app centralized in a central area centered around the avatar the user controls to engage in tasks and "gameified" content. The avatar, or "dust buddy",can be customized and upgraded based on rewards users receive for completing tasks. Each completed score corresponds to fighting against a monster that a group of roommates must defeat together. The app also features anonymous voting for users to ensure that their fellow roommates are completing tasks in a satisfactory manner. Along with this, built-in messaging features enable steady coordination and collaboration between roommates.',
        ],
      },
      outcome: {
        heading: 'Outcome and Next Steps',
        content: [
          'Additional user data was collected following the development of the final Dust Buddies prototype. Feedback indicated that the collaborative approach to roommate mediation based on "gameified" content led to a greater sense of accountability when enaging with tasks. Users also felt more eager to particpate with the interface when avatar personalization and a strong visual aesthetic was introduced',
          'The next steps for this project involve full stack implementation in order to publish as a comprehensive app experience. We will be leveraging the MERN stack framework to ensure mobile optimization, with plans to publish in May of 2026.',
        ],
      },
      tools: {
        heading: 'Tools Used',
        content: ['Figma', 'React', 'MongoDB'],
      },
    },
  },
];

/* ------------------ MAIN COMPONENT ------------------ */

export default function ProjectsSection({ onLayout }) {
  const [expandedId, setExpandedId] = useState(null);

  /* ---- Animated title state (ONLY ADDITION) ---- */
  const [scale] = useState(new RNAnimated.Value(1));
  const [color, setColor] = useState('#000');

  const handleHoverIn = () => {
    RNAnimated.spring(scale, {
      toValue: 1.1,
      useNativeDriver: true,
    }).start();
    setColor('#3b9ca1');
  };

  const handleHoverOut = () => {
    RNAnimated.spring(scale, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
    setColor('#000');
  };

  return (
    <View onLayout={onLayout} style={styles.container}>
      <Pressable onHoverIn={handleHoverIn} onHoverOut={handleHoverOut}>
        <RNAnimated.Text
          style={[
            styles.sectionTitle,
            { transform: [{ scale }], color },
          ]}
        >
          projects
        </RNAnimated.Text>
      </Pressable>

      <View style={styles.separator} />

      <Text style={styles.sectionDescription}>
        Select projects presented as research-based case studies.
      </Text>

      {projects.map(project => {
        const isExpanded = expandedId === project.id;

        return (
          <View key={project.id} style={styles.projectItem}>
            <Pressable
              onPress={() =>
                setExpandedId(isExpanded ? null : project.id)
              }
            >
              <ProjectCard {...project} />
              <Text style={styles.expandText}>
                {isExpanded ? 'Hide Case Study' : 'View Case Study'}
              </Text>
            </Pressable>

            {isExpanded && (
              <View style={styles.caseStudy}>
                {Object.entries(project.caseStudy).map(
                  ([key, section]) => {
                    if (key === 'images') {
                      return (
                        <ImageRow key={key} images={section} />
                      );
                    }

                    return (
                      <AnimatedCaseSection
                        key={key}
                        label={section.heading}
                        texts={section.content}
                      />
                    );
                  }
                )}

                {project.link && (
                  <Pressable
                    style={styles.linkButton}
                    onPress={() => Linking.openURL(project.link)}
                  >
                    <Text style={styles.linkButtonText}>
                      View Project
                    </Text>
                  </Pressable>
                )}
              </View>
            )}
          </View>
        );
      })}
    </View>
  );
}

/* ------------------ CASE SECTION ------------------ */

function AnimatedCaseSection({ label, texts }) {
  return (
    <View style={styles.caseSection}>
      <Text style={styles.caseLabel}>{label}</Text>

      {texts.map((text, index) => {
        const opacity = useSharedValue(0);

        useEffect(() => {
          opacity.value = withDelay(
            index * 120,
            withTiming(1, {
              duration: 400,
              easing: Easing.out(Easing.cubic),
            })
          );
        }, []);

        const animatedStyle = useAnimatedStyle(() => ({
          opacity: opacity.value,
          transform: [{ translateY: opacity.value ? 0 : 8 }],
        }));

        return (
          <Animated.Text
            key={index}
            style={[styles.caseText, animatedStyle]}
          >
            {text}
          </Animated.Text>
        );
      })}
    </View>
  );
}

/* ------------------ IMAGES ------------------ */

function ImageRow({ images }) {
  return (
    <View style={styles.imageSection}>
      {images.map((item, idx) => (
        <View key={idx} style={styles.imageWrapper}>
          <Image source={item.src} style={styles.caseImage} />
          {item.caption && (
            <Text style={styles.imageCaption}>
              {item.caption}
            </Text>
          )}
        </View>
      ))}
    </View>
  );
}

/* ------------------ STYLES ------------------ */

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#daf2f2',
  },
  sectionTitle: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'Arial',
  },
  separator: {
    height: 4,
    width: 60,
    backgroundColor: '#3b9ca1',
    marginVertical: 20,
    alignSelf: 'center',
  },
  sectionDescription: {
    textAlign: 'center',
    marginBottom: 30,
    color: '#666',
    fontSize: 15,
    fontStyle: 'italic',
  },
  projectItem: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16,
    marginBottom: 28,
  },
  expandText: {
    marginTop: 10,
    color: '#3b9ca1',
    fontWeight: '500',
    textAlign: 'center',
    fontSize: 18,
  },
  caseStudy: {
    marginTop: 20,
    borderTopWidth: 1,
    borderColor: '#ddd',
    paddingTop: 20,
  },
  caseSection: {
    marginBottom: 22,
  },
  caseLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  caseText: {
    fontSize: 18,
    lineHeight: 22,
    color: '#555',
    marginBottom: 8,
  },
  imageSection: {
    marginBottom: 24,
  },
  imageWrapper: {
    marginBottom: 10,
    backgroundColor: '#e4f2ee',
    padding: 10,
    borderRadius: 14,
  },
  caseImage: {
    width: '100%',
    aspectRatio: 16 / 9,
    resizeMode: 'contain',
    borderRadius: 12,
  },
  imageCaption: {
    fontSize: 16,
    color: '#666',
    marginTop: 2,
    textAlign: 'center',
    fontStyle: 'bold',
  },
  linkButton: {
    marginTop: 10,
    backgroundColor: '#3b9ca1',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  linkButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
